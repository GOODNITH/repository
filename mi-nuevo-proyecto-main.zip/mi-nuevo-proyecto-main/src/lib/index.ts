import { TURSO_CONECTION_URL,  TURSO_AUTH_TOKEN } from '$env/static/private' ; 
import * as schema from './schemna';
import {drizzle} from 'drizzle-orm/libsql';
import {createClient} from '@libsql/client';

const client = createClient ({
    url: TURSO_CONECTION_URL,
    authToken: TURSO_AUTH_TOKEN
})

export const db = drizzle (client, {schema});