<script>
    import Micomponente from "./Micomponente.svelte";
</script>
<h1> vaticueva </h1>
<p>Visit <a href="https://kit.svelte.dev">kit.svelte.dev</a> to read the documentation</p>
<Micomponente pais= colombia capital = BOGOTA ></Micomponente>
<style>
h1 {
    font-size: 60px;
    text-align: center;
    color:rgb(14, 6, 85);
  }

  p {
    color: rgb(0, 0, 0);
    font-size: large;
    
  }
  </style>

  
