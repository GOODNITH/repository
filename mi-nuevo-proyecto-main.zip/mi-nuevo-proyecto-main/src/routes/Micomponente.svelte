<script>
    let {pais, capital} = $props()
</script>

<h1>este es el: <div class="color">{pais}</div> </h1>
<h1>{capital}</h1>
<p>
    Lorem ipsum dolor sit amet consectetur adipisicing elit. Porro amet cumque asperiores perspiciatis sed dolor doloremque. Beatae, odit in delectus et pariatur, doloremque veniam, accusantium nobis omnis cumque labore quisquam!
</p>

<style>
    .color {
        color: blue;
    }
</style>